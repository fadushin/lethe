//
// Copyright (c) dushin.net
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of dushin.net nor the
//       names of its contributors may be used to endorse or promote products
//       derived from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY dushin.net ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL dushin.net BE LIABLE FOR ANY
// DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

var Lethe = {

    KVO: Class.create(
        DC.KVO,
        {
            constructor: function(object) {
                var name, value;
                for (name in object) {
                    if (object.hasOwnProperty(name) && typeof object[name] != 'function') {
                        this.setValueForKeyPath(object[name], name);
                    }
                }
            }
        }
    ),
    
    SHA: __import(this, "titaniumcore.crypto.SHA"),
    
    jsonrpc: JSOlait.imprt("jsonrpc"),
    
    create: function(backend) {
    
        var that = this;
        
        backend = backend ? backend : {
        
            dummyChannels: {},
            
            join: function(channelName, peer) {
                var dummyChannel = this.dummyChannels[channelName];
                if (!dummyChannel) {
                    dummyChannel = {peers: {}, messages: []};
                    this.dummyChannels[channelName] = dummyChannel;
                }
                dummyChannel.peers[peer.id] = peer;
            },

            getPeers: function(channelName, peerNames) {
                var dummyChannel = this.dummyChannels[channelName];
                var ret = {add: [], remove: []};
                if (!dummyChannel) {
                    return ret;
                }
                var i
                for (i = 0;  i < peerNames.length;  ++i) {
                    var peerName = peerNames[i];
                    var dummyPeer = dummyChannel.peers[peerName];
                    if (!dummyPeer) {
                        ret.remove.push(peerName);
                    }
                }
                for (dummyPeerName in dummyChannel.peers) {
                    if (!net_dushin_foundation.Lists.contains(dummyPeerName, peerNames)) {
                        ret.add.push(dummyChannel.peers[dummyPeerName]);
                    }
                }
                return ret;
            },
            
            leave: function(channelName) {
                delete this.dummyChannels[channelName];
            }
        };
        
        var sha = this.SHA.create("SHA-1");
        
        var hash = function(str) {
            return utf82str(sha.hash(str2utf8(str)));
        }

        var identityToPeer = function(identity) {
            var blob = createPeerBlob(identity);
            var id = hash(blob);
            return {
                id: id,
                blob: blob
            }
        };

        var createPeerBlob = function(identity) {
            var name = identity.valueForKeyPath("name");
            var publicKey = identity.valueForKeyPath("publicKey");
            var signer = identity.valueForKeyPath("signer");
            var signedObject = signer.sign({name: name});
            return base64_encode(
                str2utf8(
                    that.jsonrpc.marshall(
                        {
                            publicKey: publicKey, 
                            signedData: signedObject
                        }
                    )
                )
            );
        };
        
        var parsePeer = function(bepeer) {
            var deblob = parsePeerBlob(bepeer.blob);
            var verifier = net_dushin_crypto.VerifierFactory.createVerifier(
                {publicKey: deblob.publicKey}
            );
            try {
                var result = verifier.verify(deblob.signedData);
                if (!result.status) {
                    alert("Signature verification failed!");
                    throw "Signature verification failed";
                }
                var peer = result.value;
                peer.publicKey = deblob.publicKey;
                peer.id = bepeer.id;
                return peer;
            } catch (e) {
                alert(e);
                throw e;
            }
        };

        var parsePeerBlob = function(blob) {
            return that.jsonrpc.unmarshall(utf82str(base64_decode(blob)));
        };
        
        return {
            
            joinChannel: function(identity, channel) {
                var peer = identityToPeer(identity);
                var channelName = channel.valueForKeyPath("name");
                backend.join(channelName, peer);
            },
            
            updateChannel: function(channel) {
                if (!channel.running) {
                    console.log("Shutting down update function for channel " + channel.name);
                    clearInterval(channel.intervalId);
                    return;
                }
                console.log("Updating channel " + channel.name + "...");
                //
                //
                //
                var channelName = channel.valueForKeyPath("name");
                var peers = channel.valueForKeyPath("peers");
                var peerNames = net_dushin_foundation.Lists.map(
                    function(peer) {
                        return peer.id;
                    },
                    peers
                );
                //
                //
                //
                var peerUpdate = backend.getPeers(channelName, peerNames);
                //
                // Remove the peers that should be removed from the model,
                // and add the ones that should be added.
                //
                var i;
                for (i = 0;  i < peerUpdate.remove.length;  ++i) {
                    var peerName = peerUpdate.remove[i];
                    var peer = net_dushin_foundation.Lists.find(
                        function(peer) {
                            return peer.valueForKeyPath("name") === peerName;
                        },
                        peers
                    );
                    if (peer != null) {
                        peers.removeObject(peer);
                    }
                }
                for (i = 0;  i < peerUpdate.add.length;  ++i) {
                    var peer = parsePeer(peerUpdate.add[i]);
                    peers.addObject(
                        new Lethe.Peer(peer.id, peer.name, peer.publicKey, false)
                    );
                }
                // @TODO messages
            },
                
            leaveChannel: function(identityName, channel) {
                var channelName = channel.valueForKeyPath("name");
                backend.leave(channelName, identityName);
            },
            
            updateIdentity: function(oldName, identity, channels) {
                var i;
                for (i = 0;  i < channels.length;  ++i) {
                    var channel = channels[i];
                    if (oldName) {
                        this.leaveChannel(oldName, channel);
                    }
                    this.joinChannel(identity, channel);
                    this.updateChannel(channel);
                }
            }
        };
    }
};

Lethe.Identity = Class.create(
    Lethe.KVO,
    {
        constructor: function(name, privateKey, publicKey, signMessages) {
            this.base(
                {name: name, privateKey: privateKey, publicKey: publicKey, signMessages: signMessages}
            );
        }
    }
);

Lethe.Peer = Class.create(
    Lethe.KVO,
    {
        constructor: function(id, name, publicKey, encryptTo) {
            this.base(
                {id: id, name: name, publicKey: publicKey, encryptTo: encryptTo}
            );
        }
    }
);

Lethe.Message = Class.create(
    Lethe.KVO,
    {
        constructor: function(from, message) {
            this.base(
                {from: from, message: message}
            );
        },
        
        toString: function() {
            return from + ": " + message;
        }
    }
);

Lethe.instance = Lethe.create();
    
