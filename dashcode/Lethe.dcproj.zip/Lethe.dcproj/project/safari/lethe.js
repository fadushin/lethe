var Lethe = {};

Lethe.KVO = Class.create(
    DC.KVO,
    {
        constructor: function(object) {
            var name, value;
            for (name in object) {
                if (object.hasOwnProperty(name) && typeof object[name] != 'function') {
                    this.setValueForKeyPath(object[name], name);
                }
            }
        }
    }
);


Lethe.Identity = Class.create(
    Lethe.KVO,
    {
        constructor: function(name, privateKey, publicKey, signMessages) {
            this.base(
                {name: name, privateKey: privateKey, publicKey: publicKey, signMessages: signMessages}
            );
        }
        
        /*
        ,
        
        getName: function() {
            return this.valueForKeyPath('name');
        }
        */
    }
);

Lethe.Peer = Class.create(
    Lethe.KVO,
    {
        constructor: function(name, publicKey, encryptTo) {
            this.base(
                {name: name, publicKey: publicKey, encryptTo: encryptTo}
            );
        }
    }
);


Lethe.Message = Class.create(
    Lethe.KVO,
    {
        constructor: function(from, message) {
            this.base(
                {from: from, message: message}
            );
        },
        
        toString: function() {
            return from + ": " + message;
        }
    }
);
