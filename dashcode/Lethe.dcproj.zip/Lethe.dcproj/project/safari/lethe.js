//
// Copyright (c) dushin.net
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of dushin.net nor the
//       names of its contributors may be used to endorse or promote products
//       derived from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY dushin.net ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL dushin.net BE LIABLE FOR ANY
// DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

var Lethe = {

    KVO: Class.create(
        DC.KVO,
        {
            constructor: function(object) {
                var name, value;
                for (name in object) {
                    if (object.hasOwnProperty(name) && typeof object[name] != 'function') {
                        this.setValueForKeyPath(object[name], name);
                        this[name] = object[name];
                    }
                }
            },
            
            serialize: function(obj) {
                return net_dushin_foundation.Serialization.serialize(obj);
            }
        }
    ),
    
    create: function(backend) {
    
        var that = this;
        
        backend = backend ? backend : {
        
            dummyChannels: {},
            
            join: function(channelName, peer) {
                var dummyChannel = this.dummyChannels[channelName];
                if (!dummyChannel) {
                    dummyChannel = {peers: {}, messages: []};
                    this.dummyChannels[channelName] = dummyChannel;
                }
                dummyChannel.peers[peer.id] = peer;
            },

            getPeers: function(channelName, peerNames) {
                var dummyChannel = this.dummyChannels[channelName];
                var ret = {add: [], remove: []};
                if (!dummyChannel) {
                    return ret;
                }
                var i
                for (i = 0;  i < peerNames.length;  ++i) {
                    var peerName = peerNames[i];
                    var dummyPeer = dummyChannel.peers[peerName];
                    if (!dummyPeer) {
                        ret.remove.push(peerName);
                    }
                }
                for (dummyPeerName in dummyChannel.peers) {
                    if (!net_dushin_foundation.Lists.contains(dummyPeerName, peerNames)) {
                        ret.add.push(dummyChannel.peers[dummyPeerName]);
                    }
                }
                return ret;
            },
            
            leave: function(channelName) {
                delete this.dummyChannels[channelName];
            }
        };
        
        var BROWSER_STORAGE_WARNING = "Your browser does not support localStorage."
            + "  Your identity will not be preserved across sessions of your web browser."
            + "  Try an HTML5-compliant broswer, such as one based on WebKit.";

        var setStoredItem = function(key, value) {
            if (localStorage) {
                return localStorage.setItem(key, value);
            } else {
                console.info(BROWSER_STORAGE_WARNING);
                return null;
            }
        };

        var getStoredItem = function(key) {
            if (localStorage) {
                return localStorage.getItem(key);
            } else {
                console.info(BROWSER_STORAGE_WARNING);
                return null;
            }
        };
        
        return {
        
            getModel: function() {
                return dashcode.getDataSource("lethe");
            },
            
            getIdentity: function() {
                return this.getModel().valueForKeyPath("content.identity");
            },
            
            setIdentity: function(identity) {
                this.getModel().setValueForKeyPath(identity, "content.identity");
            },
            
            getTmpIdentity: function() {
                return this.getModel().valueForKeyPath("content.tmp.id");
            },
            
            // setTmpIdentity: function(identity) {
                // this.getModel().setValueForKeyPath(identity, "content.tmp.id");
            // },
            
            getChannels: function() {
                return this.getModel().valueForKeyPath("content.channels");
            },
            
            joinChannel: function(channelName) {
                var identity = this.getIdentity();
                var channels = this.getChannels();
                //
                // Check to ensure that the channel is not already created
                //
                var i;
                for (i = 0;  i < channels.length;  ++i) {
                    if (channels[i].getName() === channelName) {
                        alert("The channel name must be unique.  Please try again.");
                        return;
                    }
                }
                //
                // Join the channel (on the back end)
                //
                var obj = identity.toPeerObject();
                backend.join(channelName, obj);
                //
                // Create the channel and add it to the list of channels
                //
                var channel = new Lethe.Channel(channelName, backend);
                channels.addObject(channel);
            },
            
            leaveChannel: function(channel) {
                var channels = this.getChannels();
                var channelName = channel.valueForKeyPath('name');
                //
                // Signal the update function to stop
                //
                channel.setValueForKeyPath(false, 'running');
                // clearInterval(channel.updateId)
                //
                // remove the channel from the back end
                //
                backend.leave(channelName);
                //
                // remove it from the model
                //
                var index = net_dushin_foundation.Lists.indexOf(
                    function(chan) {
                        return chan.getName() === channelName
                    },
                    channels
                );
                if (index !== -1) {
                    channels.removeObjectAtIndex(index);
                }
            },
            
            updateIdentity: function(oldName, identity) {
                var channels = this.getChannels();
                var i;
                for (i = 0;  i < channels.length;  ++i) {
                    var channel = channels[i];
                    var channelName = channel.getName();
                    if (oldName) {
                        backend.leave(channelName);
                    }
                    var obj = identity.toPeerObject();
                    backend.join(channelName, obj);
                    channel.update();
                }
            },
    
            getStoredIdentity: function() {
                var item = getStoredItem("net.dushin.lethe.identity");
                if (item) {
                    try {
                        return Lethe.Identity.deserialize(item);
                    } catch (e) {
                        alert(e);
                        return null;
                    }
                } else {
                    return null;
                }
            },
    
            setStoredIdentity: function(identity) {
                var str = identity.serialize();
                setStoredItem("net.dushin.lethe.identity", str);
            }
        };
    }
};

Lethe.KVO.deserialize = function(str) {
    return net_dushin_foundation.Serialization.deserialize(str);
}

Lethe.Identity = Class.create(
    Lethe.KVO,
    {
        constructor: function(name, privKey, pubKey) {
            this.base(
                {
                    name: name, 
                    privKey: privKey, 
                    pubKey: pubKey,
                    //
                    // derived properties
                    //
                    signer: privKey ? net_dushin_crypto.SignerFactory.createSigner(
                        {privateKey: privKey}
                    ) : null
                }
            );
        },
        
        assign: function(identity) {
            this.privKey = identity.privKey;
            this.setValueForKeyPath(identity.pubKey, "pubKey");
            this.signer = identity.privKey ? net_dushin_crypto.SignerFactory.createSigner(
                {privateKey: identity.privKey}
            ) : null;
            this.setValueForKeyPath(identity.name, "name");
        },
        
        getName: function() {
            return this.name;
        },
        
        setName: function(nom) {
            this.name = nom;
        },
        
        serialize: function() {
            return this.base(
                {
                    name: this.name,
                    privKey: this.privKey,
                    pubKey: this.pubKey
                }
            );
        },

        createPeerBlob: function() {
            var name = this.valueForKeyPath("name");
            var pubKey = this.valueForKeyPath("pubKey");
            var signer = this.valueForKeyPath("signer");
            var signedObject = signer.sign({name: name});
            return net_dushin_foundation.Serialization.serialize(
                {
                    pubKey: pubKey, 
                    signedData: signedObject
                }
            );
        },
        
        toPeerObject: function() {
            var blob = this.createPeerBlob();
            var id = net_dushin_foundation.Serialization.sha1Hash(blob);
            return {
                id: id,
                blob: blob
            };
        },
        
        setKey: function(privKey, pubKey) {
            this.privKey = privKey;
            this.pubKey = pubKey;
            this.signer = net_dushin_crypto.SignerFactory.createSigner(
                {privateKey: privKey}
            );
        }
    }
);


Lethe.Identity.deserialize = function(str) {
    var obj = Lethe.KVO.deserialize(str);
    return new Lethe.Identity(
        obj.name, obj.privKey, obj.pubKey
    );
};

Lethe.Channel = Class.create(
    Lethe.KVO,
    {
        constructor: function(name, backend) {
            var that = this;
            this.base(
                {
                    name: name,
                    backend: backend,
                    signMessages: true,
                    peers: [], 
                    messages: [],
                    running: true,
                    updateId: setInterval(
                        function() {
                            that.update();
                        },
                        5000
                    )
                }
            );
            setTimeout(
                that.update(),
                0
            );
        },
        
        getName: function() {
            return this.name;
        },
        
        getPeers: function() {
            return this.peers;
        },
        
        update: function() {
            var channelName = this.name; // this.valueForKeyPath('name');
            if (!this.running) {
                console.log("Shutting down update function for channel " + channelName);
                clearInterval(this.intervalId);
                return;
            }
            console.log("Updating channel " + channelName + "...");
            //
            // Get the peer ids out of the ppers
            //
            var peers = this.valueForKeyPath('peers');
            var peerIds = net_dushin_foundation.Lists.map(
                function(peer) {
                    return peer.valueForKeyPath('peerId');
                },
                peers
            );
            //
            // Call getPeers on the back end, for the channel name, and
            // with the current list of peer IDs.  This will return a
            // list of the peer IDs that should be removed, and a list of
            // peers that should be added.
            //
            var peerUpdate = this.valueForKeyPath('backend').getPeers(channelName, peerIds);
            //
            // Remove the peers that should be removed from the model,
            //
            var i;
            for (i = 0;  i < peerUpdate.remove.length;  ++i) {
                var peerId = peerUpdate.remove[i];
                var peer = net_dushin_foundation.Lists.find(
                    function(peer) {
                        return peer.valueForKeyPath('peerId') === peerId;
                    },
                    peers
                );
                if (peer != null) {
                    peers.removeObject(peer);
                }
            }
            //
            // and add the ones that should be added.
            //
            for (i = 0;  i < peerUpdate.add.length;  ++i) {
                var parsedPeer = Lethe.Peer.parse(peerUpdate.add[i]);
                peers.addObject(parsedPeer);
            }
            // TODO update the messages
        },
        
        shutdown: function() {
            
        }
    }
);

Lethe.Peer = Class.create(
    Lethe.KVO,
    {
        constructor: function(peerId, name, pubKey, encryptTo) {
            this.base(
                {
                    peerId: peerId,
                    name: name, 
                    pubKey: pubKey, 
                    encryptTo: encryptTo,
                    //
                    //
                    //
                    encryptor: net_dushin_crypto.EncryptorFactory.createEncryptor(
                        {publicKey: pubKey}
                    )
                }
            );
        }/*,
        
        getPeerId: function() {
            return this.peerId;
        }*/
    }
);

Lethe.Peer.parse = function(obj) {
    var deblob = net_dushin_foundation.Serialization.deserialize(obj.blob);
    var verifier = net_dushin_crypto.VerifierFactory.createVerifier(
        {publicKey: deblob.pubKey}
    );
    try {
        var result = verifier.verify(deblob.signedData);
        if (!result.status) {
            alert("Signature verification failed!");
            throw "Signature verification failed";
        }
        var verifiedData = result.value;
        return new Lethe.Peer(
            obj.id,
            verifiedData.name,
            deblob.pubKey,
            false
        );
    } catch (e) {
        alert(e);
        throw e;
    }
};


Lethe.Message = Class.create(
    Lethe.KVO,
    {
        constructor: function(from, message) {
            this.base(
                {from: from, message: message}
            );
        },
        
        toString: function() {
            return from + ": " + message;
        }
    }
);

Lethe.init = function() {
    var lethe = Lethe.create();
    lethe.setIdentity(new Lethe.Identity("", "", ""));
    // lethe.setTmpIdentity(new Lethe.Identity("", "", ""));
    this.instance = lethe;
    /*
    var identityChangedFunction = function(change) {
        console.log("Identity changed:");
        console.log(change.oldValue);
        console.log(change.newValue);
        if (change.newValue) {
            Lethe.instance.setStoredIdentity(lethe.getIdentity());
            var oldValue = change.oldValue;
            if (oldValue) {
                Lethe.instance.updateIdentity(oldValue, lethe.getIdentity());
            }
        }
    };
    Lethe.create().getModel().addObserverForKeyPath(
        {},
        identityChangedFunction,
        "content.identity.name"
    );
    */
    return lethe;
};

