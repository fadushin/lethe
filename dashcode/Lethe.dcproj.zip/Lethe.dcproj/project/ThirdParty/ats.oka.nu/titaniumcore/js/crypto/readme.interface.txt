<html>
<head>
<title>About *.interface.txt</title>
<style>
body {
padding:0px;
margin:0px;
border:0px;
background-image:url(http://ats.oka.nu/titaniumcore/js/background.png);
background-repeat:repeat-y;
background-position: center center;
background-color:#ffffff;
font-family: "Arial", sans-serif;
/*font-family: sans-serif; */
}
#d1 {
text-align:center;
width:100%;
}
#d2 {
border:0px solid gray;
text-align:left;
min-width:none;
width:650px;
margin-left:auto;
margin-right:auto;
padding:30px;
}
</style>
</head>
<body>
<div id="d1">
<pre id="d2">


    About *.interface.txt

                                                           Titaniumcore Project
================================================================================
Atsushi Oka [ <a href="http://oka.nu/">http://oka.nu/</a> ]                                      Jan 15,2009

A text file that has the extension ``.interface.txt'' is a description for
JavaScript interface.  Since JavaScript has no type restriction, there is
no particular script file that defines the class interface implicitly. The
specification of the interface is described In the text files that has the
extension ``.interface.txt'' .


================================================================================

// vim:expandtab:

</pre>
</div>
</body>
</html>
