{
    identity: {
        name: "",
        privateKey: "",
        publicKey: "",
        signMessages: true
    },
    channels: [
        { 
            name: "Acadia",
            signMessages: true,
            peers: [
                {
                    name: "Margot",
                    publicKey: "gRhttTO5x1Cr5AJ3Aw1bOv1Nq8aTkkz2lqIeku2d7X4y/sMQ/gzv1vp7repv/20i0tPGgR8rQud4uDuBz32ANCjGdViXtXOdWJo2kE1HnlOJ++ZSTFXcCxCUNhnDb1OPxotfKXRxNw5P/PYP1UfmKQ==",
                    encryptTo: true 
                },
                {
                    name: "Fred1",
                    publicKey: "1zTbIQhQxlWPbvSb1G9TWe/Wani/Y2kqRUOGswEPLq3kEmgOLicwQ4lHFUvuBDydDrZcThyU/eoRsJ2sN0hYkI/wnfnu8IONIf8eLNmeI8KnYSX3jY8QA1L7rgMmGfXAVcpYUlNQXmLjq3sqlWbe8Q==",
                    encryptTo: false 
                },
                {
                    name: "Fred2",
                    publicKey: "1zTbIQhQxlWPbvSb1G9TWe/Wani/Y2kqRUOGswEPLq3kEmgOLicwQ4lHFUvuBDydDrZcThyU/eoRsJ2sN0hYkI/wnfnu8IONIf8eLNmeI8KnYSX3jY8QA1L7rgMmGfXAVcpYUlNQXmLjq3sqlWbe8Q==",
                    encryptTo: false 
                },
                {
                    name: "Fred3",
                    publicKey: "1zTbIQhQxlWPbvSb1G9TWe/Wani/Y2kqRUOGswEPLq3kEmgOLicwQ4lHFUvuBDydDrZcThyU/eoRsJ2sN0hYkI/wnfnu8IONIf8eLNmeI8KnYSX3jY8QA1L7rgMmGfXAVcpYUlNQXmLjq3sqlWbe8Q==",
                    encryptTo: false 
                },
                {
                    name: "Fred4",
                    publicKey: "1zTbIQhQxlWPbvSb1G9TWe/Wani/Y2kqRUOGswEPLq3kEmgOLicwQ4lHFUvuBDydDrZcThyU/eoRsJ2sN0hYkI/wnfnu8IONIf8eLNmeI8KnYSX3jY8QA1L7rgMmGfXAVcpYUlNQXmLjq3sqlWbe8Q==",
                    encryptTo: false 
                },
                {
                    name: "Fred5",
                    publicKey: "1zTbIQhQxlWPbvSb1G9TWe/Wani/Y2kqRUOGswEPLq3kEmgOLicwQ4lHFUvuBDydDrZcThyU/eoRsJ2sN0hYkI/wnfnu8IONIf8eLNmeI8KnYSX3jY8QA1L7rgMmGfXAVcpYUlNQXmLjq3sqlWbe8Q==",
                    encryptTo: false 
                },
                {
                    name: "Fred6",
                    publicKey: "1zTbIQhQxlWPbvSb1G9TWe/Wani/Y2kqRUOGswEPLq3kEmgOLicwQ4lHFUvuBDydDrZcThyU/eoRsJ2sN0hYkI/wnfnu8IONIf8eLNmeI8KnYSX3jY8QA1L7rgMmGfXAVcpYUlNQXmLjq3sqlWbe8Q==",
                    encryptTo: false 
                }
            ],
            messages: [
                {
                    from: "Fred",
                    message: "Hi"
                },
                {
                    from: "Margot",
                    message: "Hi there"
                }
            ]
        }
    ]
}